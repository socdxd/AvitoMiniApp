using System.Windows;

namespace AvitoMiniApp
{
    public partial class App : Application
    {
    }
}
